package pl.polsl.database.entities;

public interface IEntity {
    @Override
    public String toString();
}
